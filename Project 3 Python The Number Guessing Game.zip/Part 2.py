import random

def guessing_game():
    answer = random.randint(0,100)
    
    while True:
        guess = int(input("What's your guess? "))
        
        if guess == answer:
            print(f"{guess} is correct!")
            break
        
        if guess > answer:
            print(f"{guess} is too high!")
            
        elif guess < answer:
            print(f"{guess} is too low")  
            
        else:
             print((f"Correct!You guessed in {attempts}attempts."))    
            
guessing_game()